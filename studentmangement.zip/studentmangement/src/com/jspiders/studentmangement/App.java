package com.jspiders.studentmangement;

public class App {

}
